package inheritance;

public class Auto extends Vehicle{

	



}
