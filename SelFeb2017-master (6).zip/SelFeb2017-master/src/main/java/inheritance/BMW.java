package inheritance;

public class BMW extends Car{
	
	public void changeColor(){
		
	}
	
	public void applyBrake(){

	}
	
	

	



}
