package inheritance;

public class Audi extends Car {



}
