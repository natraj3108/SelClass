package inheritance;

public class Car extends Vehicle{

	public void turnAC(){
		
	}



}
