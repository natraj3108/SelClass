package inheritance;

public class Vehicle {

	public void applyBrake(){

	}

	public void soundHorn(){

	}



}
