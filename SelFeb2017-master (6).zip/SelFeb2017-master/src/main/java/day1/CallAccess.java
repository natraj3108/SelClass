package day1;

import day2.AccessThisClass;

public class CallAccess {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AccessThisClass sum= new AccessThisClass();

	}

}
