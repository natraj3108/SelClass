package learnStatic;

public class LearnFinal {
	final String txt = "karim";
	
	public final void sample(){
		System.out.println("Sample Final method");
	}
	
	
	

	
	

}
