package interfa;

public class ICICI implements RBI {

	public void noMoreThan3L() {
		// TODO Auto-generated method stub
		
	}

	public void needAdh() {
		// TODO Auto-generated method stub
		
	}

	public void withDraw50K() {
		// TODO Auto-generated method stub
		
	}

}
