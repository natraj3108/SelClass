package interfa;

public interface IMF {
	
	public void manageEXcRate();
	
	public void noMoreThan3L();

}
