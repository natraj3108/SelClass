package interfa;

public class UseCon {
	
	public static void main(String[] args) {
		
		LearnConstructor lc = new LearnConstructor("s");
		
	}

}
