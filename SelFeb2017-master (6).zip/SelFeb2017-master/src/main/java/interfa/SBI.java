package interfa;

public class SBI implements RBI, IMF{

	public void noMoreThan3L() {
		// TODO Auto-generated method stub
		
	}

	public void needAdh() {
		// TODO Auto-generated method stub
		
	}

	public void manageEXcRate() {
		// TODO Auto-generated method stub
		
	}	
	
	public void loanForSeleniumDev(){
		
	}

	public void withDraw50K() {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
