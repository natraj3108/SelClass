package interfa;

public interface RBI {
	
	public abstract void noMoreThan3L();
	
	public void needAdh();
	
	public void withDraw50K();

}
