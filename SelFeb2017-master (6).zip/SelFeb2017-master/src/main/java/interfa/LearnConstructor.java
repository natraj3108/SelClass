package interfa;

public class LearnConstructor {
	
	public LearnConstructor(){
		System.out.println("In Default Constructor");
	}
	
	public LearnConstructor(String a){
		System.out.println("In Overloading Constructor");
	}

}
